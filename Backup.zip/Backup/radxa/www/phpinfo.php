2
<?php phpinfo(); ?>