var window_input_key="";
window_input_key +="<div class='window' style='height:165px;width:220px;'>";
window_input_key +="    <nav>";
window_input_key +="        <a href='#' class='close'></a>";
window_input_key +="        <a href='#' class='minimize'></a>";
window_input_key +="        <a href='#' class='maximize'></a>";
window_input_key +="        <div class='divh1'>Inputs (keys)</div>";
window_input_key +="    </nav>";

    
window_input_key +="	 <label class='tasks-list-item'>";
window_input_key +="		<span class='tasks-list-desc'>Key 1 (P8_19)</span>";
window_input_key +="    	<div class='tasks-list-mark'><input id='widgetid2001' height='30' width='55' type='checkbox' class='ios-switch tinyswitch' /><div><div></div></div></div>";
window_input_key +="	 </label>";
window_input_key +="	 <label class='tasks-list-item'>";
window_input_key +="    	<span class='tasks-list-desc'>Kachel pomp</span>";
window_input_key +="        <div class='tasks-list-mark'><input id='widgetid2002' height='30' width='55' type='checkbox' class='ios-switch tinyswitch' /><div><div></div></div></div>";
window_input_key +="	 </label>  ";

window_input_key +="     <label class='tasks-list-item'>";
window_input_key +="		<span class='tasks-list-desc'>PIR toilet</span>";
window_input_key +="    	<div class='tasks-list-mark'><input id='widgetid2003' height='30' width='55' type='checkbox' class='ios-switch tinyswitch' /><div><div></div></div></div>";
window_input_key +="	 </label>";
window_input_key +="	 <label class='tasks-list-item'>";
window_input_key +="    	<span class='tasks-list-desc'>PIR acherdeur</span>";
window_input_key +="        <div class='tasks-list-mark'><input id='widgetid2004' height='30' width='55' type='checkbox' class='ios-switch tinyswitch' /><div><div></div></div></div>";
window_input_key +="	 </label>  ";

window_input_key +="</div>";


  
function init_window_input_key(){

      
}  