var window_temp="";
window_temp +="<div class='window' style='height:340px;width:220px;'>";
window_temp +="    <nav>";
window_temp +="        <a href='#' class='close'></a>";
window_temp +="        <a href='#' class='minimize'></a>";
window_temp +="        <a href='#' class='maximize'></a>";
window_temp +="        <div class='divh1'>Temperaturen</div>";
window_temp +="    </nav>";

    
window_temp +="     <label class='tasks-list-item'>";
window_temp +="		    <span class='tasks-list-desc'>Woonkamer</span>";
window_temp +="    	    <div id='widgetid4001' class='tasks-list-mark' style='font-size: 13pt;color: #555;'>0</div>";
window_temp +="	    </label>";
window_temp +="     <label class='tasks-list-item'>";
window_temp +="    	    <span class='tasks-list-desc'>Kachel boven</span>";
window_temp +="    	    <div id='widgetid4002' class='tasks-list-mark' style='font-size: 13pt;color: #555;'>0</div>";
window_temp +="	    </label>";
window_temp +="     <label class='tasks-list-item'>";
window_temp +="    	    <span class='tasks-list-desc'>Kachel onder</span>";
window_temp +="    	    <div id='widgetid4003' class='tasks-list-mark' style='font-size: 13pt;color: #555;'>0</div>";
window_temp +="	    </label>";
window_temp +="     <label class='tasks-list-item'>";
window_temp +="		    <span class='tasks-list-desc'>Buffer boven</span>";
window_temp +="    	    <div id='widgetid4004' class='tasks-list-mark' style='font-size: 13pt;color: #555;'>0</div>";
window_temp +="	    </label>";
window_temp +="     <label class='tasks-list-item'>";
window_temp +="    	    <span class='tasks-list-desc'>Buffer midden</span>";
window_temp +="    	    <div id='widgetid4005' class='tasks-list-mark' style='font-size: 13pt;color: #555;'>0</div>";
window_temp +="	    </label>";
window_temp +="     <label class='tasks-list-item'>";
window_temp +="    	    <span class='tasks-list-desc'>Buffer onder</span>";
window_temp +="    	    <div id='widgetid4006' class='tasks-list-mark' style='font-size: 13pt;color: #555;'>0</div>";
window_temp +="	    </label>";
window_temp +="     <label class='tasks-list-item'>";
window_temp +="    	    <span class='tasks-list-desc'>Generator boven</span>";
window_temp +="    	    <div id='widgetid4007' class='tasks-list-mark' style='font-size: 13pt;color: #555;'>0</div>";
window_temp +="	    </label>";
window_temp +="     <label class='tasks-list-item'>";
window_temp +="            <span class='tasks-list-desc'>Generator onder</span>";
window_temp +="    	    <div id='widgetid4009' class='tasks-list-mark' style='font-size: 13pt;color: #555;'>0</div>";
window_temp +="	    </label>";
window_temp +="     <label class='tasks-list-item'>";
window_temp +="    	    <span class='tasks-list-desc'>Buiten</span>";
window_temp +="    	    <div id='widgetid4008' class='tasks-list-mark' style='font-size: 13pt;color: #555;'>0</div>";
window_temp +="	    </label>";

window_temp +="</section>";
  
  
function init_window_temp(){

      
}  