var window_bmv="";
window_bmv +="<div class='window' style='height:300px;width:220px;'>";
window_bmv +="    <nav>";
window_bmv +="        <a href='#' class='close'></a>";
window_bmv +="        <a href='#' class='minimize'></a>";
window_bmv +="        <a href='#' class='maximize'></a>";
window_bmv +="        <div class='divh1'>BMV-600</div>";
window_bmv +="    </nav>";

    
window_bmv +="     <label class='tasks-list-item'>";
window_bmv +="		    <span class='tasks-list-desc'>Spanning</span>";
window_bmv +="    	    <div id='widgetid3001' class='tasks-list-mark' style='font-size: 13pt;color: #555;'>0</div>";
window_bmv +="	    </label>";
window_bmv +="     <label class='tasks-list-item'>";
window_bmv +="    	    <span class='tasks-list-desc'>Stroom</span>";
window_bmv +="    	    <div id='widgetid3002' class='tasks-list-mark' style='font-size: 13pt;color: #555;'>0</div>";
window_bmv +="	    </label>";
window_bmv +="     <label class='tasks-list-item'>";
window_bmv +="    	    <span class='tasks-list-desc'>Vermogen</span>";
window_bmv +="    	    <div id='widgetid3008' class='tasks-list-mark' style='font-size: 13pt;color: #555;'>0</div>";
window_bmv +="	    </label>";
window_bmv +="     <label class='tasks-list-item'>";
window_bmv +="    	    <span class='tasks-list-desc'>CE</span>";
window_bmv +="    	    <div id='widgetid3003' class='tasks-list-mark' style='font-size: 13pt;color: #555;'>0</div>";
window_bmv +="	    </label>";
window_bmv +="     <label class='tasks-list-item'>";
window_bmv +="    	    <span class='tasks-list-desc'>SOC</span>";
window_bmv +="    	    <div id='widgetid3004' class='tasks-list-mark' style='font-size: 13pt;color: #555;'>0</div>";
window_bmv +="	    </label>";
window_bmv +="     <label class='tasks-list-item'>";
window_bmv +="    	    <span class='tasks-list-desc'>TTG</span>";
window_bmv +="    	    <div id='widgetid3005' class='tasks-list-mark' style='font-size: 13pt;color: #555;'>0</div>";
window_bmv +="	    </label>";
window_bmv +="     <label class='tasks-list-item'>";
window_bmv +="    	    <span class='tasks-list-desc'>Alarm</span>";
window_bmv +="    	    <div id='widgetid3006' class='tasks-list-mark' style='font-size: 13pt;color: #555;'>0</div>";
window_bmv +="	    </label>";
window_bmv +="     <label class='tasks-list-item'>";
window_bmv +="    	    <span class='tasks-list-desc'>Relay</span>";
window_bmv +="    	    <div id='widgetid3007' class='tasks-list-mark' style='font-size: 13pt;color: #555;'>0</div>";
window_bmv +="	    </label>";

window_bmv +="</section>";
  
  
function init_window_bmv(){

      
}  