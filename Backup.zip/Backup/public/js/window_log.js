var window_log="";
window_log +="<div class='window' style='height:156px;width:400px;'>";
window_log +="    <nav>";
window_log +="        <a href='#' class='close'></a>";
window_log +="        <a href='#' class='minimize'></a>";
window_log +="        <a href='#' class='maximize'></a>";
window_log +="        <div class='divh1'>Log</div>";
window_log +="    </nav>";
    

window_log +="<textarea id='logtextarea' rows='15' cols='57' id='aboutDescription' style='max-height:100px;min-height:100px; resize: none'></textarea>";
window_log +="<form id='send-message'>";
window_log +="	<input size='35' id='message'></input>";
window_log +="	<input type='submit'></input>";
window_log +="</form>";

window_log +="</section>";
  
  
function init_window_log(){
	//alert('init_window_log');
}  